
count = 0
sum_val = 0
min_val = float('inf')

# Read the first number
num = int(input("Enter a natural number (-1 to terminate): "))

# Process the sequence
while num != -1:
    # Update count, sum, and minimum
    count += 1
    sum_val += num
    if num < min_val:
        min_val = num

    # Read the next number
    num = int(input("Enter a natural number (-1 to terminate): "))

# Compute mean and handle the case when n = 0
if count == 0:
    mean = -1
    min_val = -1
else:
    mean = sum_val / count

# Display results
print(f"Count (n): {count}")
print(f"Sum (s): {sum_val}")
print(f"Minimum (m): {min_val}")
print(f"Mean (a): {mean}")
