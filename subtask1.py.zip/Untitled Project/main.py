def largest_square(n):
    q = 0
    while q ** 2 <= n:
        q += 1
    return (q - 1) ** 2

# Example usage for n=20
n = 20
result = largest_square(n)

print(f"For n={n} -> q={result}")
